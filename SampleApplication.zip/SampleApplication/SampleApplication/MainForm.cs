﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SampleApplication
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void addUserToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            AddUser frm = new AddUser();
            frm.MdiParent = this;
            addUserToolStripMenuItem1.Enabled = false;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Show();
        }

        private void forgotPasswordToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ForgotPassword frm = new ForgotPassword();
            frm.MdiParent = this;
            forgotPasswordToolStripMenuItem1.Enabled = false;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Show();
        }

      
        private void aDDDIEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            die frm = new die();
            frm.MdiParent = this;
            addDieToolStripMenuItem1.Enabled = false;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Show();
        }

       
        private void addHoleToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            hole frm = new hole();
            frm.MdiParent = this;
            addHoleToolStripMenuItem1.Enabled = false;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Show();
        }

        private void dieToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dieSearch frm = new dieSearch();
            frm.MdiParent = this;
            addDieToolStripMenuItem1.Enabled = false;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Show();
        }

        private void dieToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            DieReport frm = new DieReport();
            frm.MdiParent = this;
            addDieToolStripMenuItem1.Enabled = false;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Show();
        }

        private void holeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            holeReport frm = new holeReport();
            frm.MdiParent = this;
            addDieToolStripMenuItem1.Enabled = false;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.Show();
        }
    }
}
