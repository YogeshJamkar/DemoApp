﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SampleApplication
{
    public partial class hole : Form
    {
        int ID = 0;
        public hole()
        {
            InitializeComponent();
            DisplayData();
            DisplayList();
        }

        //Display Data in DataGridView  
        private void DisplayData()
        {
           DataTable dt = new DataTable();
           SqlDataAccess sda = new SqlDataAccess();
           dt = sda.Execute("Proc_GetHoleData");
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "SR NO";
            dataGridView1.Columns[1].HeaderText = "DIE NAME";
            dataGridView1.Columns[2].HeaderText = "HOLE NUMBER";
            dataGridView1.Columns[1].Width = 270;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font(DataGridView.DefaultFont, FontStyle.Bold);
            add_hole.Text = "Add";
        }
        private void ClearData()
        {
            hole_no.Text = "";
            die_name.Text = "";
            add_hole.Text = "Add";
        }


        private void add_hole_Click(object sender, EventArgs e)
        {
            try

            {
                //bool _IsActive = chkIsActive.Checked;

                SqlDataAccess sda = new SqlDataAccess();
                SqlCommand cmd = new SqlCommand("Proc_InsertUpdateDelete_HoleData");
                cmd.Parameters.AddWithValue("@id", ID);
                cmd.Parameters.AddWithValue("@die_id", die_name.SelectedValue);
                cmd.Parameters.AddWithValue("@userId", 1);
                cmd.Parameters.AddWithValue("@hole_number", hole_no.Text);
                if (add_hole.Text == "Add")
                {
                    cmd.Parameters.AddWithValue("@action", "INSERT");
                }
                else
                {
                    cmd.Parameters.AddWithValue("@action", "UPDATE");
                }

                int res = sda.ExecuteStoredProcedure(cmd);

                if (add_hole.Text == "Add")
                {
                    MessageBox.Show("Hole Added successfully");
                }
                else
                {
                    MessageBox.Show("Hole Updated successfully");
                }
                DisplayData();
                ClearData();

            }

            catch (Exception es)

            {

                MessageBox.Show(es.Message);

            }
        }

        private void hole_FormClosing(object sender, FormClosingEventArgs e)
        {
            //but if the control is owned by onther control on the parent Form I must Access parent Form then Access The Control that Holed the Control I wanna to access like a tree system
            Form frm = (Form)this.MdiParent;
            MenuStrip ms = (MenuStrip)frm.Controls["menuStrip1"];
            ToolStripMenuItem ti = (ToolStripMenuItem)ms.Items["MasterDataToolStripMenuItem"];
            ti.DropDownItems["addHoleToolStripMenuItem1"].Enabled = true;
        }

     
        //dataGridView1 RowHeaderMouseClick Event  
        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            ID = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            die_name.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            hole_no.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();

            add_hole.Text = "Update";
        }

       
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (ID != 0)
                {
                    DialogResult result1 = MessageBox.Show("Are you sure you want to delete\nrecord of " + die_name + " ?", "Warning", MessageBoxButtons.YesNo);

                    if (result1 == DialogResult.Yes)
                    {
                        SqlDataAccess sda = new SqlDataAccess();
                        SqlCommand cmd = new SqlCommand("Proc_InsertUpdateDelete_HoleData");
                        cmd.Parameters.AddWithValue("@id", ID);
                        cmd.Parameters.AddWithValue("@userId", 1);
                        cmd.Parameters.AddWithValue("@die_id", die_name.SelectedValue);
                        cmd.Parameters.AddWithValue("@hole_number", hole_no.Text);
                        cmd.Parameters.AddWithValue("@action", "DELETE");

                        int res = sda.ExecuteStoredProcedure(cmd);

                        MessageBox.Show("Die Deleted successfully");

                        DisplayData();
                        ClearData();
                    }
                }
                else
                {
                    MessageBox.Show("Please Select Record to Delete");
                }
            }

            catch (Exception es)
            {

                MessageBox.Show("Error while Insertion");

            }
        }

        private void DisplayList()
        {
            DataRow dr;
            DataTable dt = new DataTable();
            SqlConnection con = new SqlConnection(@"Data Source=YOGIRAJ\SQLEXPRESS01;Initial Catalog=demo;Integrated Security=True");
            con.Open();
            SqlCommand cmd = new SqlCommand("Proc_GetDieList", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);

            dr = dt.NewRow();
            dr.ItemArray = new object[] { 0, "--Select Die--" };
            dt.Rows.InsertAt(dr, 0);

            die_name.DisplayMember = "DieName";
            die_name.ValueMember = "Id";
            die_name.DataSource = dt;
        }

        
    }
}
