﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SampleApplication
{
    public partial class AddUser : Form
    {
        public AddUser()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtUserName.Text = "";
            txtPassword.Text = "";
            txtMobileNo.Text = "";
            txtFullName.Text = "";
            txtEmailId.Text = "";
            chkIsActive.Checked = false;
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try

            {
                bool _IsActive = chkIsActive.Checked;

                SqlDataAccess sda = new SqlDataAccess();
                SqlCommand cmd = new SqlCommand("Proc_InsertUpdate_EmployeeData");

                cmd.Parameters.AddWithValue("@UserName",txtUserName.Text);
                cmd.Parameters.AddWithValue("@Password",txtPassword.Text);
                cmd.Parameters.AddWithValue("@FullName",txtFullName.Text);
                cmd.Parameters.AddWithValue("@MobileNo",txtMobileNo.Text);
                cmd.Parameters.AddWithValue("@EmailID",txtEmailId.Text);
                cmd.Parameters.AddWithValue("@IsActive", _IsActive);
      
                int res = sda.ExecuteStoredProcedure(cmd);

                if (res==1)
                {
                    MessageBox.Show("Employee Inserted successfully");
                }
                else
                {
                    MessageBox.Show("Error while Insertion");
                }

            }

            catch (Exception es)

            {

                MessageBox.Show(es.Message);

            }
        }

        private void AddUser_FormClosing(object sender, FormClosingEventArgs e)
        {
            
            //but if the control is owned by onther control on the parent Form I must Access parent Form then Access The Control that Holed the Control I wanna to access like a tree system
            Form frm = (Form)this.MdiParent;
            MenuStrip ms = (MenuStrip)frm.Controls["menuStrip1"];
            ToolStripMenuItem ti = (ToolStripMenuItem)ms.Items["MasterDataToolStripMenuItem"];
            ti.DropDownItems["addUserToolStripMenuItem1"].Enabled = true;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
