﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace SampleApplication
{
    public partial class die : Form
    {
        //ID variable used in Updating and Deleting Record
        int ID = 0;
        public die()
        {
            InitializeComponent();
            DisplayData();
        }


        private void add_die_Click(object sender, EventArgs e)
        {
            try

            {
                if (die_no.Text != "" && die_name.Text != "")
                {
                    SqlDataAccess sda = new SqlDataAccess();
                    SqlCommand cmd = new SqlCommand("Proc_InsertUpdateDelete_DieData");
                    cmd.Parameters.AddWithValue("@id", ID);
                    cmd.Parameters.AddWithValue("@die_no", die_no.Text);
                    cmd.Parameters.AddWithValue("@userId", 1);
                    cmd.Parameters.AddWithValue("@die_name", die_name.Text);
                    if (add_hole.Text == "Add")
                    {
                        cmd.Parameters.AddWithValue("@action", "INSERT");
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@action", "UPDATE");
                    }


                    int res = sda.ExecuteStoredProcedure(cmd);

                    if (add_hole.Text == "Add")
                    {
                        MessageBox.Show("Die Inserted successfully");
                    }
                    else
                    {
                        MessageBox.Show("Die Updated successfully");
                    }
                    DisplayData();
                    ClearData();
                }
                else
                {
                    MessageBox.Show("Please Provide Details!");
                }

            }

            catch (Exception es)
            {

                MessageBox.Show("Error while Insertion");

            }

        }
        //dataGridView1 RowHeaderMouseClick Event  
        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            ID = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            die_name.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            die_no.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();

            add_hole.Text = "Update";
        }   //Display Data in DataGridView  
        private void DisplayData()
        {
            DataTable dt = new DataTable();
            SqlDataAccess sda = new SqlDataAccess();
            dt = sda.Execute("Proc_GetDieData");
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "SR NO";
            dataGridView1.Columns[1].HeaderText = "DIE NO";
            dataGridView1.Columns[2].HeaderText = "DIE NAME";
            dataGridView1.Columns[2].Width = 270;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font(DataGridView.DefaultFont, FontStyle.Bold);
            add_hole.Text = "Add";
        }

     
        private void ClearData()
        {
            die_no.Text = "";
            die_name.Text = "";
            ID = 0;
            add_hole.Text = "Add";
        }


        private void btn_Delete_Click(object sender, EventArgs e)
        {
            try
            {
                if (ID != 0)
                {
                    DialogResult result1 = MessageBox.Show("Are you sure you want to delete\nrecord of " + die_no + " ?", "Warning", MessageBoxButtons.YesNo);

                    if (result1 == DialogResult.Yes)
                    {
                        SqlDataAccess sda = new SqlDataAccess();
                        SqlCommand cmd = new SqlCommand("Proc_InsertUpdateDelete_DieData");
                        cmd.Parameters.AddWithValue("@id", ID);
                        cmd.Parameters.AddWithValue("@userId", 1);
                        cmd.Parameters.AddWithValue("@die_no", die_no.Text);
                        cmd.Parameters.AddWithValue("@die_name", die_name.Text);
                        cmd.Parameters.AddWithValue("@action", "DELETE");

                        int res = sda.ExecuteStoredProcedure(cmd);

                        MessageBox.Show("Die Deleted successfully");

                        DisplayData();
                        ClearData();
                    }
                }
                else
                {
                    MessageBox.Show("Please Select Record to Delete");
                }
            }

            catch (Exception es)
            {

                MessageBox.Show("Error while Insertion");

            }
        }


        private void die_FormClosing(object sender, FormClosingEventArgs e)
        {
            //but if the control is owned by onther control on the parent Form I must Access parent Form then Access The Control that Holed the Control I wanna to access like a tree system
            Form frm = (Form)this.MdiParent;
            MenuStrip ms = (MenuStrip)frm.Controls["menuStrip1"];
            ToolStripMenuItem ti = (ToolStripMenuItem)ms.Items["MasterDataToolStripMenuItem"];
            ti.DropDownItems["addDieToolStripMenuItem1"].Enabled = true;

        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
