﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SampleApplication
{
    public partial class DieReport : Form
    {
        public DieReport()
        {
            InitializeComponent();
            DisplayData();
        }

        //Display Data in DataGridView  
        private void DisplayData()
        {
            DataTable dt = new DataTable();
            SqlDataAccess sda = new SqlDataAccess();
            dt = sda.Execute("Proc_GetDieData");
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "SR NO";
            dataGridView1.Columns[1].HeaderText = "DIE NO";
            dataGridView1.Columns[2].HeaderText = "DIE NAME";
            dataGridView1.Columns[2].Width = 270;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font(DataGridView.DefaultFont, FontStyle.Bold);
           
        }

        private void DieReport_Load(object sender, EventArgs e)
        {

        }
    }
}
