﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace SampleApplication
{
    public partial class dieSearch : Form
    {
        string cs =@"Data Source=YOGIRAJ\SQLEXPRESS01;Initial Catalog=demo;Integrated Security=True";
        SqlConnection con;
        SqlDataAdapter adapt;
        DataTable dt;
       
        public dieSearch()
        {
            InitializeComponent();
            DisplayData();
        }
        //Display Data in DataGridView  
        private void DisplayData()
        {
            DataTable dt = new DataTable();
            SqlDataAccess sda = new SqlDataAccess();
            dt = sda.Execute("Proc_GetDieData");
            dataGridView1.DataSource = dt;
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "SR NO";
            dataGridView1.Columns[1].HeaderText = "DIE NO";
            dataGridView1.Columns[2].HeaderText = "DIE NAME";
            dataGridView1.Columns[1].Width = 105;
            dataGridView1.Columns[2].Width = 280;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font(DataGridView.DefaultFont, FontStyle.Bold);


        }
        private void button1_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(cs);
            con.Open();
            adapt = new SqlDataAdapter("select Id, DieNo, DieName from DieMaster where DieName like '" + search_box.Text + "%'", con);
            dt = new DataTable();
            adapt.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "SR NO";
            dataGridView1.Columns[1].HeaderText = "DIE NO";
            dataGridView1.Columns[2].HeaderText = "DIE NAME";
            dataGridView1.Columns[1].Width = 105;
            dataGridView1.Columns[2].Width = 280;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font(DataGridView.DefaultFont, FontStyle.Bold);
            
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }
    }
}
