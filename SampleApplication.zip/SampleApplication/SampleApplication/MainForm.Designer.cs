﻿namespace SampleApplication
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.MasterDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addUserToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.addDieToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.addHoleToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.forgotPasswordToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dieToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.holeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MasterDataToolStripMenuItem,
            this.reportToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1043, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // MasterDataToolStripMenuItem
            // 
            this.MasterDataToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addUserToolStripMenuItem1,
            this.addDieToolStripMenuItem1,
            this.addHoleToolStripMenuItem1,
            this.forgotPasswordToolStripMenuItem1,
            this.searchToolStripMenuItem});
            this.MasterDataToolStripMenuItem.Name = "MasterDataToolStripMenuItem";
            this.MasterDataToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.MasterDataToolStripMenuItem.Text = "MasterData";
            // 
            // addUserToolStripMenuItem1
            // 
            this.addUserToolStripMenuItem1.Name = "addUserToolStripMenuItem1";
            this.addUserToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.addUserToolStripMenuItem1.Text = "Add User";
            this.addUserToolStripMenuItem1.Click += new System.EventHandler(this.addUserToolStripMenuItem1_Click);
            // 
            // addDieToolStripMenuItem1
            // 
            this.addDieToolStripMenuItem1.Name = "addDieToolStripMenuItem1";
            this.addDieToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.addDieToolStripMenuItem1.Text = "Add Die";
            this.addDieToolStripMenuItem1.Click += new System.EventHandler(this.aDDDIEToolStripMenuItem_Click);
            // 
            // addHoleToolStripMenuItem1
            // 
            this.addHoleToolStripMenuItem1.Name = "addHoleToolStripMenuItem1";
            this.addHoleToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.addHoleToolStripMenuItem1.Text = "Add Hole";
            this.addHoleToolStripMenuItem1.Click += new System.EventHandler(this.addHoleToolStripMenuItem1_Click);
            // 
            // forgotPasswordToolStripMenuItem1
            // 
            this.forgotPasswordToolStripMenuItem1.Name = "forgotPasswordToolStripMenuItem1";
            this.forgotPasswordToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.forgotPasswordToolStripMenuItem1.Text = "Change Password";
            this.forgotPasswordToolStripMenuItem1.Click += new System.EventHandler(this.forgotPasswordToolStripMenuItem1_Click);
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dieToolStripMenuItem});
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.searchToolStripMenuItem.Text = "Search";
            // 
            // dieToolStripMenuItem
            // 
            this.dieToolStripMenuItem.Name = "dieToolStripMenuItem";
            this.dieToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.dieToolStripMenuItem.Text = "Die";
            this.dieToolStripMenuItem.Click += new System.EventHandler(this.dieToolStripMenuItem_Click);
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dieToolStripMenuItem1,
            this.holeToolStripMenuItem});
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.reportToolStripMenuItem.Text = "Report";
            // 
            // dieToolStripMenuItem1
            // 
            this.dieToolStripMenuItem1.Name = "dieToolStripMenuItem1";
            this.dieToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.dieToolStripMenuItem1.Text = "Die ";
            this.dieToolStripMenuItem1.Click += new System.EventHandler(this.dieToolStripMenuItem1_Click);
            // 
            // holeToolStripMenuItem
            // 
            this.holeToolStripMenuItem.Name = "holeToolStripMenuItem";
            this.holeToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.holeToolStripMenuItem.Text = "Hole";
            this.holeToolStripMenuItem.Click += new System.EventHandler(this.holeToolStripMenuItem_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImage = global::SampleApplication.Properties.Resources._01;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1043, 495);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainForm";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem MasterDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addUserToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem forgotPasswordToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem reportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addDieToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem addHoleToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dieToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem holeToolStripMenuItem;
    }
}