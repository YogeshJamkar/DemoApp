﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SampleApplication
{
    public partial class ForgotPassword : Form
    {
        public ForgotPassword()
        {
            InitializeComponent();
        }

        private void ForgotPassword_FormClosing(object sender, FormClosingEventArgs e)
        {
           
            //but if the control is owned by onther control on the parent Form I must Access parent Form then Access The Control that Holed the Control I wanna to access like a tree system
            Form frm = (Form)this.MdiParent;
            MenuStrip ms = (MenuStrip)frm.Controls["menuStrip1"];
            ToolStripMenuItem ti = (ToolStripMenuItem)ms.Items["MasterDataToolStripMenuItem"];
            ti.DropDownItems["forgotPasswordToolStripMenuItem1"].Enabled = true;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtUserName.Text = "";
            txtOldPassword.Text = "";
            txtNewPassword.Text = "";
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {

        }
    }
}
