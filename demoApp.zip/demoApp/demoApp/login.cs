﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace demoApp
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //label4.Hide();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            register frm2 = new register();
            frm2.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (empId.Text != "" && password.Text != "")
            {
                SqlConnection con = new SqlConnection(@"Data Source=YOGIRAJ\SQLEXPRESS01;Initial Catalog=demo;Integrated Security=True;");
                con.Open();
                String str1 = "SELECT first_name,name,email FROM employee WHERE name='" + empId.Text + "' AND password='" + password.Text + "'";
                SqlCommand cmd1 = new SqlCommand(str1, con);
                SqlDataAdapter adp = new SqlDataAdapter(str1, con);
                DataTable dt = new DataTable();
                adp.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    SqlDataReader dr;
                    dr = cmd1.ExecuteReader();
                    if (dr.Read())
                    {
                        Dashboard dash = new Dashboard(dr["first_name"].ToString());
                        this.Hide();
                        dash.Show();
                    } 
                }
                else
                {
                    MessageBox.Show("The username or password you entered is incorrect!", "Logon Message!");
                }
            }
            else
            {
                MessageBox.Show("Please Enter Valid Details", "Logon Message!");
            }
        }
    }
}
