﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace demoApp
{
    public partial class register : Form
    {
        public register()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            //label5.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (emp_id.Text != "" && first_name.Text != "" && last_name.Text != "" && email.Text != "" && password.Text != "" && cpassword.Text != "")
            {

                int count = 1;
                if (password.Text == password.Text)
                {
                    SqlConnection con = new SqlConnection(@"Data Source=YOGIRAJ\SQLEXPRESS01;Initial Catalog=demo;Integrated Security=True;");
                    String str = "INSERT INTO employee(id,name,email,first_name,last_name,password) values('" + count++ + "','" + emp_id.Text + "','" + email.Text + "','" + first_name.Text + "', '" + last_name.Text + "','" + password.Text + "')";
                    con.Open();
                    SqlCommand cmd = new SqlCommand(str, con);
                    cmd.ExecuteNonQuery();
                    emp_id.Text = "";
                    first_name.Text = "";
                    last_name.Text = "";
                    email.Text = "";
                    password.Text = "";
                    password.Text = "";
                    MessageBox.Show("Register Succesfully", "Register");
                    this.Hide();
                    login login = new login();
                    login.Show();
                }
                else
                {
                    MessageBox.Show("Password did't match", "Register");
                }
            }
            else
            {
                MessageBox.Show("All Field Required", "Register");
                emp_id.Focus(); 
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            login frm = new login();
            frm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            login frm = new login();
            frm.Show();
        }
    }
}
